document.addEventListener("DOMContentLoaded", function () {
    var count = 0;
    var total = 0;
    var maxSeats = 5; // Maximum seats that can be selected

    // Get all available seats
    var seats = document.querySelectorAll(".seatAvailable");
    var seatOccupy = document.querySelectorAll("seatOccupied")


    // Add click event listeners to available seats
    seats.forEach(function (seat) {
        seat.addEventListener("click", function () {
            if (!seat.classList.contains("seatSelected") && count < maxSeats && !seat.classList.contains("seatOccupied")) {
                seat.classList.add("seatSelected");
                count++;
                total += 300; // Assuming $10 per seat
                updateSeats();
            } else if (seat.classList.contains("seatSelected") && !seat.classList.contains("seatOccupied")) {
                seat.classList.remove("seatSelected");
                count--;
                total -= 300;
                updateSeats();
            }
        });
    });

    // Handle confirmation button click
    var confirmButton = document.getElementById("myFunction");
    confirmButton.addEventListener("click", function () {
        var selectedSeats = document.querySelectorAll(".seatSelected");

        if (selectedSeats.length === 0) {
            alert("Please select at least one seat.");
            return;
        }


        selectedSeats.forEach(function (seat) {
            seat.classList.remove("seatSelected");
            seat.classList.add("seatOccupied");
        });
        count = 0;
        total = 0;
        updateSeats();
    });

    // Function to update seat count and total price in the summary
    function updateSeats() {
        var countElement = document.getElementById("count");
        var totalElement = document.getElementById("total");
        countElement.innerText = count;
        totalElement.innerText = total;
    }
});
