/*--------------book now-------------------*/
var count=0;
var seats=document.getElementsByClassName("seatAvailable");
var seatSelect = document.getElementsByClassName("seatSelected")
for(var i=0;i<seats.length;i++){
     var item=seats[i];

     item.addEventListener("click",(event)=>{
        var price= 10;


        if (!event.target.classList.contains('seatOccupied') && count<5){
            if(event.target.classList.contains('seatSelected')){
                count--;
                event.target.classList.remove("seatSelected")
            }else{
                count++;
                 event.target.classList.remove("seatAvailable");
                event.target.classList.add("seatSelected")
            }
            var total=count*price;
            document.getElementById("count").innerText=count;
            document.getElementById("total").innerText=total;
        }
        /*if (count === 5) {
            // Disable click event listener for all available seats when count reaches 5
            for (var j = 0; j < seats.length; j++) {
                seats[j].removeEventListener("click");
            }
       }*/

   })
}


/*
function myFunction(){
    for(var i=0; i<seatSelect.length;i++){
        seatSelect[i].classList.add("seatOccupied")
        seatSelect[i].classList.remove("seatSelected")
    }
}
*/
document.getElementById("myFunction").addEventListener("click", () => {
    var selectedSeats = document.getElementsByClassName("seatSelected");

    for (var i = 0; i < selectedSeats.length; i++) {
        var seat = selectedSeats[i];
        seat.classList.remove("seatSelected");
        seat.classList.add("seatOccupied");
    }

    count = 0; // Reset the count when seats are occupied
    document.getElementById("count").innerText = count;
    document.getElementById("total").innerText = "0";
});



